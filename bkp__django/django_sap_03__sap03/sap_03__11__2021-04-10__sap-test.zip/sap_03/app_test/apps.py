# ../app_test/apps.py

from django.apps import AppConfig


class AppTestConfig(AppConfig):
    name = 'app_test'
