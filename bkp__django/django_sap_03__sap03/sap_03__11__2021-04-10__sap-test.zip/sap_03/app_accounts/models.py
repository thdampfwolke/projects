# ../app_accounts/models.py

from django.db import models

# Create your models here.
