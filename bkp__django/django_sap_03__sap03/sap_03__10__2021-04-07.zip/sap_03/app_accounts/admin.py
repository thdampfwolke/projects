# ../app_accounts/admin.py

from django.contrib import admin

# Register your models here.
