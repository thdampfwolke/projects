# ../app_accounts/apps.py

from django.apps import AppConfig

class AppAccountsConfig(AppConfig):
    name = 'app_accounts'
