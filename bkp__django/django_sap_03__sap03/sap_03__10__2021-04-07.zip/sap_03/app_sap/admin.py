# ../app_sap/admin.py

from django.contrib import admin
from .models import Mitarbeiter2

admin.site.register(Mitarbeiter2)
