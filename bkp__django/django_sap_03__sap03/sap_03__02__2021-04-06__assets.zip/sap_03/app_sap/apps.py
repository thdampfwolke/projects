from django.apps import AppConfig


class AppSapConfig(AppConfig):
    name = 'app_sap'
