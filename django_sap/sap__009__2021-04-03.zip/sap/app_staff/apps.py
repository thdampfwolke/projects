from django.apps import AppConfig


class AppStaffConfig(AppConfig):
    name = 'app_staff'
